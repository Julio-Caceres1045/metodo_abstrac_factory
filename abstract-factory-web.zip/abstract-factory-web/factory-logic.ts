
// --- INTERFACES (PRODUCTOS ABSTRACTOS) ---

interface DocumentElement {
    render(content: string): string;
}

interface Title extends DocumentElement {}
interface Title2 extends DocumentElement {} // NUEVO
interface Title3 extends DocumentElement {}
interface Paragraph extends DocumentElement {}
interface Quote extends DocumentElement {}


// --- INTERFAZ (ABSTRACT FACTORY) ---

interface DocumentFactory {
    createTitle1(): Title;
    createTitle2(): Title2; // NUEVO
    createTitle3(): Title3;
    createParagraph(): Paragraph;
    createQuote(): Quote;
}


// --- PRODUCTOS CONCRETOS (IMPLEMENTACIONES DE ELEMENTOS) ---

// === Familia HTML ===
class Title1HTML implements Title {
    render(content: string): string {
        return `<h1>${content}</h1>\n`;
    }
}

class Title2HTML implements Title2 { // NUEVO
    render(content: string): string {
        return `<h2>${content}</h2>\n`;
    }
}

class Title3HTML implements Title3 { // NUEVO
    render(content: string): string {
        return `<h3>${content}</h3>\n`;
    }
}

class ParagraphHTML implements Paragraph {
    render(content: string): string {
        return `<p>${content}</p>\n`;
    }
}

class QuoteHTML implements Quote {
    render(content: string): string {
        return `<blockquote>${content}</blockquote>\n`;
    }
}

// === Familia MARKDOWN ===
class Title1MD implements Title {
    render(content: string): string {
        return `# ${content}\n`;
    }
}

class Title2MD implements Title2 { // NUEVO
    render(content: string): string {
        return `## ${content}\n`;
    }
}

class Title3MD implements Title3 { // NUEVO
    render(content: string): string {
        return `### ${content}\n`;
    }
}

class ParagraphMD implements Paragraph {
    render(content: string): string {
        return `${content}\n`;
    }
}

class QuoteMD implements Quote {
    render(content: string): string {
        const lines = content.split('\n');
        return lines.map(line => `> ${line}`).join('\n') + '\n';
    }
}


// --- FÁBRICAS CONCRETAS ---

class HTMLFactory implements DocumentFactory {
    createTitle1(): Title { return new Title1HTML(); }
    createTitle2(): Title2 { return new Title2HTML(); } // NUEVO
    createTitle3(): Title3 { return new Title3HTML(); } // NUEVO
    createParagraph(): Paragraph { return new ParagraphHTML(); }
    createQuote(): Quote { return new QuoteHTML(); }
}

class MarkdownFactory implements DocumentFactory {
    createTitle1(): Title { return new Title1MD(); }
    createTitle2(): Title2 { return new Title2MD(); } // NUEVO
    createTitle3(): Title3 { return new Title3MD(); } // NUEVO
    createParagraph(): Paragraph { return new ParagraphMD(); }
    createQuote(): Quote { return new QuoteMD(); }
}

// --- CLIENTE (DOCUMENT PROCESSOR) ---

// Estructura de la data recibida del JSON
interface JsonElement {
    tipo: 'titulo1' | 'parrafo' | 'cita' | string;
    contenido: string;
}

interface DocumentData {
    convert: 'html' | 'markdown' | string;
    elementos: JsonElement[];
}

class DocumentProcessor {
    private factory: DocumentFactory;

    constructor(factory: DocumentFactory) {
        this.factory = factory;
    }

    private createElement(type: string): DocumentElement {
        switch (type) {
            case 'titulo1':
                return this.factory.createTitle1();
            case 'titulo2': // NUEVO
                return this.factory.createTitle2();
            case 'titulo3': // NUEVO
                return this.factory.createTitle3();
            case 'parrafo':
                return this.factory.createParagraph();
            case 'cita':
                return this.factory.createQuote();
            default:
                throw new Error(`Tipo de elemento no soportado: ${type}`);
        }
    }

    public generateOutput(data: DocumentData): string {
        let finalOutput = '';

        for (const element of data.elementos) {
            try {
                // El procesador crea el objeto usando la fábrica abstracta
                const docElement = this.createElement(element.tipo);
                finalOutput += docElement.render(element.contenido);
            } catch (error) {
                const errorMessage = error instanceof Error ? error.message : "Error al procesar el elemento.";
                finalOutput += `[ERROR: ${errorMessage}]\n`;
            }
        }
        return finalOutput;
    }
}


// --- LÓGICA DE SERVICIO (EXPORTADA) ---

// Función auxiliar para seleccionar la fábrica
function getFactory(format: string): DocumentFactory {
    const lowerFormat = format.toLowerCase().trim();
    if (lowerFormat === 'html') {
        return new HTMLFactory();
    } else if (lowerFormat === 'markdown' || lowerFormat === 'md') {
        return new MarkdownFactory();
    } else {
        throw new Error(`Formato de conversión '${format}' no válido. Use 'html' o 'markdown'.`);
    }
}

/**
 * Función principal que será llamada por el servidor Express.
 * Recibe la data JSON y utiliza el patrón Abstract Factory para generar el documento.
 */
export function processDocumentFromData(jsonData: any): string {
    const data: DocumentData = jsonData as DocumentData; // Asumimos que la data es válida
    const format = data.convert;
    
    if (!format) {
        throw new Error("El campo 'convert' no se encontró o está vacío en el JSON.");
    }

    // 1. Obtener la fábrica correcta
    const factory = getFactory(format);
    
    // 2. Inicializar el procesador con la fábrica seleccionada
    const processor = new DocumentProcessor(factory);
    
    // 3. Generar la salida
    return processor.generateOutput(data);
}

