/**
 * Determina el modo de entrada seleccionado (texto o archivo).
 * @returns {'text' | 'file'}
 */
function getSelectedMode() {
    const radios = document.getElementsByName('input_mode');
    for (const radio of radios) {
        if (radio.checked) {
            return radio.value;
        }
    }
    return 'text'; // Valor por defecto
}

/**
 * Función principal que orquesta la lectura de datos y la conversión.
 */
async function convertDocument() {
    const outputContainer = document.getElementById('output-container');
    outputContainer.innerHTML = 'Procesando...';
    
    const mode = getSelectedMode();
    let jsonText = '';

    // 1. LECTURA DE DATOS SEGÚN EL MODO
    if (mode === 'text') {
        // Modo: Pegar Texto JSON
        const jsonInput = document.getElementById('json-input');
        jsonText = jsonInput.value;
    } else if (mode === 'file') {
        // Modo: Subir Archivo JSON
        const fileInput = document.getElementById('json-file-input');
        const file = fileInput.files[0];

        if (!file) {
            outputContainer.innerHTML = '<span style="color: red; font-weight: bold;">[ERROR] Por favor, selecciona un archivo .json.</span>';
            return;
        }

        // Leer el contenido del archivo de forma asíncrona
        try {
            jsonText = await readFileAsText(file);
        } catch (e) {
            outputContainer.innerHTML = '<span style="color: red; font-weight: bold;">[ERROR] Error al leer el archivo.</span>';
            return;
        }
    }

    // 2. PARSEO DE DATOS
    let jsonData;
    try {
        jsonData = JSON.parse(jsonText);
    } catch (e) {
        outputContainer.innerHTML = '<span style="color: red; font-weight: bold;">[ERROR] JSON inválido. Revisa la sintaxis.</span>';
        return;
    }

    // 3. ENVÍO AL SERVIDOR (Backend)
    fetch('/convert', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(jsonData)
    })
    .then(response => response.json())
    .then(data => {
        // 4. Manejar la respuesta y mostrar el resultado
        if (data.success) {
            let htmlOutput = `<h4>Resultado (${data.format}):</h4>`;
            
            // Queremos mostrar el código generado, no que el navegador lo interprete.
            if (data.format === 'HTML') {
                // Escapamos el HTML para que se muestre como texto
                htmlOutput += `<pre>${data.output.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</pre>`;
            } else {
                 // Markdown se muestra como texto de todas formas
                 htmlOutput += `<pre>${data.output}</pre>`;
            }
            
            outputContainer.innerHTML = htmlOutput;
        } else {
            outputContainer.innerHTML = `<span style="color: red; font-weight: bold;">[ERROR de Servidor] ${data.error}</span>`;
        }
    })
    .catch((error) => {
        console.error('Error de red/fetch:', error);
        outputContainer.innerHTML = '<span style="color: red; font-weight: bold;">[ERROR de Red] No se pudo conectar con el servidor (localhost:3000).</span>';
    });
}

/**
 * Función auxiliar para leer el contenido de un archivo como texto.
 * Retorna una Promesa.
 * @param {File} file - El objeto File a leer.
 * @returns {Promise<string>}
 */
function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target.result);
        reader.onerror = (e) => reject(e);
        reader.readAsText(file);
    });
}