// server.ts

import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import * as path from 'path';
// Importamos la función de procesamiento que usa el patrón Abstract Factory
import { processDocumentFromData } from './factory-logic'; 

const app = express();
const port = 3000;

// --- Configuración de Middleware ---

// 1. body-parser: Para analizar los cuerpos JSON de las peticiones POST
app.use(bodyParser.json());

// 2. express.static: Para servir archivos estáticos (Frontend) desde la carpeta 'public'
app.use(express.static(path.join(__dirname, 'public')));


// --- Ruta de Procesamiento (API) ---

// Esta ruta recibe el JSON enviado por el frontend (app.js)
app.post('/convert', (req: Request, res: Response) => {
    try {
        const jsonData = req.body;

        // Validación básica de la entrada
        if (!jsonData || !jsonData.convert) {
            return res.status(400).json({ 
                error: "JSON inválido. Asegúrate de que contiene la estructura y el campo 'convert'." 
            });
        }
        
        // Ejecutamos la lógica de la Fábrica Abstracta
        const output = processDocumentFromData(jsonData);
        
        // Enviamos la respuesta de éxito al frontend
        res.json({ 
            success: true, 
            format: jsonData.convert.toUpperCase(),
            output: output 
        });

    } catch (error) {
        // Manejo de errores durante la conversión (ej: formato no soportado de la fábrica)
        const errorMessage = error instanceof Error ? error.message : "Error desconocido en el servidor.";
        res.status(500).json({ error: errorMessage });
    }
});


// --- Inicio del Servidor ---

app.listen(port, () => {
    console.log(`🚀 Servidor iniciado en http://localhost:${port}`);
    console.log(`Abre tu navegador y visita http://localhost:${port}`);
});